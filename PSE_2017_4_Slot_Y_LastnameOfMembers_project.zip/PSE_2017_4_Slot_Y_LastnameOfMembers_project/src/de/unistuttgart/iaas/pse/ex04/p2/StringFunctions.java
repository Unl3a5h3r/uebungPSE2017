package de.unistuttgart.iaas.pse.ex04.p2;

public class StringFunctions {

	public static int numberOfDiphthongs(String testString) {
		return 0;
	}

	public static boolean isPalindrome(String testString) {
		return false;
	}

	public static void main(String[] args) {

	}

}