package de.unistuttgart.iaas.pse.ex04.p1;

public class IOConsole {

	
	public static double computeCircleArea(double radius) {
		return 0.0;
	}

	public static double computeCircleCircumference(double radius) {
		return 0.0;
	}

	public static double computeRectangleArea(double a, double b) {
		return 0.0;
	}

	public static double computeRectangleCircumference(double a, double b) {
		return 0.0;
	}

	public static double computeTriangleArea(double a, double b) {
		return 0.0;
	}

	public static double computeTriangleCircumference(double a, double b) {
		return 0.0;
	}

	public static void printMenu() {

	}

	public static void main(String[] args) {
		printMenu();
	}

}