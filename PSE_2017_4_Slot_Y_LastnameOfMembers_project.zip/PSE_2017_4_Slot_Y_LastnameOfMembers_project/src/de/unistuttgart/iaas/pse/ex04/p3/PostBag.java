package de.unistuttgart.iaas.pse.ex04.p3;

import java.util.ArrayList;

public class PostBag {

	/**
	 * returns all letters contained in the postbag
	 * 
	 * @return all letters contained in the postbag
	 */
	public ArrayList<Letter> getLetters() {
		return null;
	}

	/**
	 * adds letters to the postbag
	 * 
	 * @param letters
	 *            the letters to add
	 */
	public void addLetter(Letter... letters) {
		
	}
	
}